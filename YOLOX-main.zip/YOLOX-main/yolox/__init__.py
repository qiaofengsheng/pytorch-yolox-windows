#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from .utils import configure_module

configure_module()

__version__ = "0.1.0"
