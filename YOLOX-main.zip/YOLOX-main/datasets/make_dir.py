import os

os.makedirs(r'VOCdevkit\VOC2007\Annotations')
os.makedirs(r'VOCdevkit\VOC2007\ImageSets\Main')
os.makedirs(r'VOCdevkit\VOC2007\JPEGImages')