import os
import random


train_pr=0.7

xml_names=os.listdir('VOCdevkit/VOC2007/Annotations')
nums=len(xml_names)

train_nums=int(train_pr*nums)

list=range(nums)
train_index=random.sample(list,train_nums)

train_val=open('VOCdevkit/VOC2007/ImageSets/Main/trainval.txt','w')
test=open('VOCdevkit/VOC2007/ImageSets/Main/test.txt','w')

for i in list:
    name=xml_names[i].split('.')[0]+'\n'
    if i in train_index:
        train_val.write(name)
    else:
        test.write(name)

train_val.close()
test.close()

